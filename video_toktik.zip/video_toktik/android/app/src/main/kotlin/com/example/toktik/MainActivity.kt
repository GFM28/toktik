package com.example.toktik

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
