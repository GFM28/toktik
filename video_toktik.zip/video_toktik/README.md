# Toktik - A Flutter Project

## Importante:
Los videos no están incluídos en el repositorio, debido a que son muy pesados y GitHub no lo permite.

Pueden descargar 8 videos de aquí:
[Pexels Free Videos](https://www.pexels.com/search/videos/vertical/)

Renombren esos videos así, ya que es lo que se encuentra en nuestro data source.
```
1.mp4
2.mp4
3.mp4
4.mp4
5.mp4
6.mp4
7.mp4
8.mp4
```
